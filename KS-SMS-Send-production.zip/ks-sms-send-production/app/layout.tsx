import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KS SMS Send",
  description: "Plateforme d'envoi de SMS",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fr"><body>{children}</body></html>;
}
