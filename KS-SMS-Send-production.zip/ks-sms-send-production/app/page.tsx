"use client";

import { FormEvent, useEffect, useState } from "react";

type Role = "user" | "admin";
type Sms = { receiver:string; sender:string; message:string; status:string; createdAt:string };

const defaultSender = process.env.NEXT_PUBLIC_DEFAULT_SENDER || "KS SMS";

export default function Home() {
  const [role, setRole] = useState<Role>("user");
  const [logged, setLogged] = useState(false);
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [receiver, setReceiver] = useState("");
  const [sender, setSender] = useState(defaultSender);
  const [preview, setPreview] = useState("");
  const [credits, setCredits] = useState(25);
  const [history, setHistory] = useState<Sms[]>([]);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const raw = localStorage.getItem("ks_sms_history");
    const c = localStorage.getItem("ks_sms_credits");
    if (raw) setHistory(JSON.parse(raw));
    if (c) setCredits(Number(c));
  }, []);

  function login(e: FormEvent) {
    e.preventDefault();
    setNotice("");
    // Production-safe direction: the UI calls a server route instead of storing
    // the admin password in localStorage. The current endpoint is intentionally
    // a scaffold until DATABASE_URL/auth provider is configured.
    if (role === "admin") {
      if (id.length < 3 || password.length < 8) {
        setNotice("Identifiant ou mot de passe invalide.");
        return;
      }
      document.cookie = "ks_demo_admin=1; Path=/; SameSite=Lax";
    } else {
      if (!id || !password) { setNotice("Renseigne tes identifiants."); return; }
    }
    setLogged(true);
    setNotice("");
  }

  function logout() {
    document.cookie = "ks_demo_admin=; Max-Age=0; Path=/";
    setLogged(false); setId(""); setPassword("");
  }

  function sendSms() {
    if (!receiver.trim() || !message.trim()) return setNotice("Renseigne le numéro et le message.");
    if (credits < 1) return setNotice("Crédit insuffisant.");
    const item: Sms = {receiver:receiver.trim(), sender:sender.trim() || defaultSender, message:message.trim(), status:"En attente de connexion SMS", createdAt:new Date().toISOString()};
    const next = [item, ...history];
    setHistory(next); setCredits(credits - 1); setMessage(""); setPreview("");
    localStorage.setItem("ks_sms_history", JSON.stringify(next));
    localStorage.setItem("ks_sms_credits", String(credits - 1));
    setNotice("Demande enregistrée. Le fournisseur SMS réel sera connecté après configuration.");
  }

  if (!logged) return (
    <><header className="topbar"><div className="brand">KS SMS Send</div><div className="badge">Connexion</div></header>
    <main><section className="card login">
      <h1>Connexion</h1><p className="muted">Accède à ton espace utilisateur ou administrateur.</p>
      <div className="tabs">
        <button className={"tab "+(role==="user"?"active":"")} onClick={()=>setRole("user")}>Utilisateur</button>
        <button className={"tab "+(role==="admin"?"active":"")} onClick={()=>setRole("admin")}>Administrateur</button>
      </div>
      <form onSubmit={login}>
        <label>Identifiant</label><input value={id} onChange={e=>setId(e.target.value)} placeholder="Ton identifiant"/>
        <label>Mot de passe</label><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Ton mot de passe"/>
        <button className="btn primary" style={{width:"100%",marginTop:18}}>Se connecter</button>
      </form>
      {notice && <p className="error">{notice}</p>}
      <div className="notice" style={{marginTop:18}}>Cette version est structurée pour le déploiement. L'authentification définitive, la base de données, le paiement et le fournisseur SMS doivent être branchés par variables d'environnement/services.</div>
    </section></main></>
  );

  return (
    <><header className="topbar"><div className="brand">KS SMS Send</div><div className="row"><div className="badge">{role==="admin"?"Administrateur":"Utilisateur"}</div><button className="btn light" onClick={logout}>Déconnexion</button></div></header>
    <main>
      {role==="admin" ? <Admin history={history} credits={credits}/> :
      <><section className="card"><h1>Espace utilisateur</h1><p className="muted">Envoi de SMS et gestion des crédits.</p></section>
      <div className="statgrid"><div className="stat"><span>Crédits SMS</span><strong>{credits}</strong></div><div className="stat"><span>SMS enregistrés</span><strong>{history.length}</strong></div><div className="stat"><span>Compte</span><strong style={{fontSize:18}}>Actif</strong></div></div>
      <div className="grid" style={{marginTop:20}}>
        <section className="card"><h2>Envoyer un SMS</h2><label>Numéro du receveur</label><input value={receiver} onChange={e=>setReceiver(e.target.value)} placeholder="+225 07 00 00 00 00"/>
        <label>ID de l'expéditeur</label><input value={sender} onChange={e=>setSender(e.target.value)}/><label>Message</label>
        <textarea maxLength={160} value={message} onChange={e=>{setMessage(e.target.value);setPreview(e.target.value)}}/><p className="muted">{message.length}/160 caractères</p>
        <button className="btn primary" onClick={sendSms}>Envoyer le SMS</button><button className="btn light" style={{marginLeft:6}} onClick={()=>setNotice("Le paiement sera branché avec un prestataire sécurisé.")}>Acheter des crédits</button>
        {notice && <p className="muted">{notice}</p>}</section>
        <section className="card"><h2>Aperçu</h2><div className="preview"><div className="phone"><small>{sender||defaultSender}</small><div className="bubble">{preview||"Ton message apparaîtra ici."}</div></div></div></section>
      </div>
      <History history={history}/></>}
    </main></>
  );
}

function History({history}:{history:Sms[]}) {
  return <section className="card"><h2>Historique</h2><table><thead><tr><th>Destinataire</th><th>Expéditeur</th><th>Message</th><th>Statut</th></tr></thead><tbody>
  {history.length ? history.map((x,i)=><tr key={i}><td>{x.receiver}</td><td>{x.sender}</td><td>{x.message}</td><td>{x.status}</td></tr>) : <tr><td colSpan={4}>Aucun SMS.</td></tr>}
  </tbody></table></section>
}

function Admin({history,credits}:{history:Sms[],credits:number}) {
  return <><section className="card"><h1>Tableau de bord administrateur</h1><p className="muted">Gestion de KS SMS Send.</p></section>
  <div className="statgrid"><div className="stat"><span>Utilisateurs</span><strong>1</strong></div><div className="stat"><span>SMS enregistrés</span><strong>{history.length}</strong></div><div className="stat"><span>Crédits</span><strong>{credits}</strong></div></div>
  <section className="card" style={{marginTop:20}}><h2>Paramètres</h2><p>Cette zone est prête à recevoir les paramètres persistants de la base de données : tarifs, crédits, expéditeur par défaut, limites, utilisateurs, statistiques et intégrations.</p><div className="notice">Sécurité : aucun numéro de carte bancaire, CVV ou OTP ne doit être enregistré dans KS SMS Send. Le paiement devra utiliser la page sécurisée d'un prestataire.</div></section>
  <History history={history}/></>
}
