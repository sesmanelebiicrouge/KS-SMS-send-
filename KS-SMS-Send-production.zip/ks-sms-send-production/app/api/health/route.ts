import { NextResponse } from "next";

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "KS SMS Send",
    status: "ready-for-deployment",
    smsProviderConfigured: Boolean(process.env.SMS_API_URL && process.env.SMS_API_KEY),
    databaseConfigured: Boolean(process.env.DATABASE_URL),
    paymentConfigured: Boolean(process.env.PAYMENT_SECRET_KEY)
  });
}
